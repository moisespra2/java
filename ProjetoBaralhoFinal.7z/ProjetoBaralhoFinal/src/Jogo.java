import model.Baralho;
import model.Carta;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Jogo {
    //Defini uma classe pro Jogador e a mão que ele tem ao jogar, o array eu usei para guardar a informacao das cartas, mas o IntelliJ deu auto-complete
    private static class Jogador {
        private final List<Carta> mao = new ArrayList<>();

        public void adicionarCarta(Carta carta) {
            mao.add(carta);

            //Adiciona carta a mao do jogador
        }

        public int getPontuacao() {
            int pontuacao = 0;
            int ases = 0;
            // a variavel ases foi para saber quando houvesse algum As na mao do jogador

            //A lógica que pensei de inicio era como eu poderia fazer com que o As tivesse dois valores, pensei no inicio em usar if e else, mas n estava funcionando
            //Usando o for e o while ja foi possivel, admito que demorei para conseguir, e perguntei no GPT qual seria o melhor jeito de adicionar, nele ele mostrou o codigo
            //mas o que eu queria de informacao era qual parametro usar, e como vi que estava usando for, eu tentei fazer por conta e saiu assim.

            for (Carta carta : mao) {
                pontuacao += carta.getValor();
                if (carta.toString().startsWith("As")) {
                    ases++;

                    //Aqui a logica foi para adicionar a pontuacao para o jogador saber, e caso fosse um as, colocar 1 ou 11 dependendo do valor que ele estaria na mao
                }
            }

            while (pontuacao > 21 && ases > 0) {
                pontuacao -= 10; // Considera o Ás como 1 em vez de 11
                ases--;

                //Continuando, se o As fosse 11 e a pontuacao do jogador ultrapassasse 21, o as automaticamente receberia uma subtracao de 10 no seu valor,
                //deixando ele com o valor de apenas 1
            }
            return pontuacao; //retorna a pontuacao do jogador


        }

        public List<Carta> getMao() {
            return mao; //Retorna a mao final do jogador no sistema
        }

        @Override
        public String toString() {
            return mao.toString() + " (Total: " + getPontuacao() + ")"; //E aqui apresenta a pontuacao no programa
        }
        }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Embaralhamento de cartas do baralho
        Baralho baralho = new Baralho();
        baralho.embaralharCartas();
        //baralho.exibirCartas();
        //Achei melhor nao exibir as cartas, quando rodei o jogo, ele mostrava todas as cartas embaralhadas, e na minha visáo ficou feio.

        Jogador jogador = new Jogador();
        Jogador desafiador = new Jogador();

        //Aqui criei o jogador e o desafiante (Quis fazer como no blackjack original, no qual a "casa" que fornece o jogo tem o distribuidor
        //das cartas e tambem e o desafiante de quem quiser jogar o jogo

        // Distribuindo cartas iniciais
        for (int i = 0; i < 2; i++) {
            jogador.adicionarCarta(baralho.tirarCarta());
            desafiador.adicionarCarta(baralho.tirarCarta());
        } //Aqui foi um for simples, para adicionar duas cartas no maximo para cada um

        System.out.println("Suas cartas: " + jogador);
        System.out.println("Carta do desafiador: " + desafiador.getMao().get(0) + " e uma carta escondida.");

        // Turno do jogador
        while (true) {
            System.out.print("Deseja comprar mais cartas? [s/n]? ");
            String acao = scanner.nextLine();
            if (acao.equalsIgnoreCase("s")) { //Aqui coloquei para ignorar o Caixa Alta, e também para apenas aceita s ou n como opcao
                jogador.adicionarCarta(baralho.tirarCarta());
                System.out.println("Suas cartas: " + jogador);
                if (jogador.getPontuacao() > 21) {
                    System.out.println("Você estourou! O desafiador ganha.");
                    return;
                }
            } else if (acao.equalsIgnoreCase("n")) {
                break;
            }
        }

        // Turno do desafiador
        System.out.println("Cartas do desafiador: " + desafiador.getMao());
        while (desafiador.getPontuacao() < 17) {
            desafiador.adicionarCarta(baralho.tirarCarta());
            System.out.println("Desafiador comprou uma carta. Cartas do desafiador: " + desafiador);

            //Aqui para o desafiante eu usei a logica que se a pontuacao fosse menor que 17 ele precisa comprar ate que ultrapasse
            //a pontuacao de 17 ao menos, isso vi que eh uma regra do blackjack, por isso apliquei aqui
        }

        // Verificando vencedor
        int pontuacaoJogador = jogador.getPontuacao();
        int pontuacaoDesafiador = desafiador.getPontuacao();

        if (pontuacaoDesafiador > 21) {
            System.out.println("O desafiador estourou! Você ganha.");
        } else if (pontuacaoJogador > pontuacaoDesafiador) {
            System.out.println("Você ganha!");
        } else if (pontuacaoJogador < pontuacaoDesafiador) {
            System.out.println("O desafiador ganha.");
        } else {
            System.out.println("Empate!");
        }
        //Por fim ul if, elseif, para verificar o vencedor
    }
    }

