package model;

public enum Naipe {
    Copas,
    Ouro,
    Espada,
    Paus
}
