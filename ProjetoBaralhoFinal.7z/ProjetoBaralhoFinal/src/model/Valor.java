package model;

public enum Valor {

    Dois(2),
    Tres(3),
    Quatro(4),
    Cinco(5),
    Seis(6),
    Sete(7),
    Oito(8),
    Nove(9),
    Dez(10),
    Valete(10),
    Dama(10),
    Reis(10),
    As(11);

    //Aqui apenas adicionei os valores inteiros para cada carta,
    // e declarei uma variavel privada como int para o valor

    private int valor;

    Valor(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }
}