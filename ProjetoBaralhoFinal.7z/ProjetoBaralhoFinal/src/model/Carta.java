package model;

public class Carta {
    private Naipe naipe;
    private Valor valor;

    //construtor
    public Carta(Naipe naipe, Valor valor) {
        this.naipe = naipe;
        this.valor = valor;
    }

    public int getValor() {
        return valor.getValor();
        //Aqui eu puxei o getValor do enumerador Valor, no qual precisava para ler os valores das cartas
    }

    public void setValor(Valor valor) {
        this.valor = valor;

        //Precisei adicionar o metodo setValor, por conta do "AS", ja que no jogo ele pode mudar o valor de 1 para 11
    }

    @Override
    public String toString() {
        return valor + " de " + naipe;
    }
}
